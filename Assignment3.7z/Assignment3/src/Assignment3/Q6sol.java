package Assignment3;

//#6. Are static methods
//	a) inherited
//	b) method overriding

class BaseA {

	public static void printSomething() {
		System.out.println("Printing .....from base static");
	}

	public void print() {
		System.out.println("printing from Base Instance method");
	}

}

public class Q6sol extends BaseA {

//	static method overriding
	public static void printSomething() {
		System.out.println("Printing .....from derived static");
	}

	public void print() {
		System.out.println("Printing from Drive Instance method");
	}

	public static void main(String[] args) {
		BaseA obj = new Q6sol();
//		calling inherited static method
		obj.printSomething();
		obj.print();
	}

}
