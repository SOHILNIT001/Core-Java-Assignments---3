package Assignment3;

//#1. create a small program which calls main method itself recursively forever. pls share your observations?

public class Q1sol {

	public static void main(String[] args) {
			myMeth1();
	}

	public static void myMeth1() {
		System.out.println("Mymeth1() called");
		myMeth1();
	}
	
}
