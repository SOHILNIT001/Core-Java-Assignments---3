package Assignment3;

//enum can be declared outside the class also

//#2. Make changes to enum example, Season, and use Season as return type?

enum Season {
	WINTER, SPRING, SUMMER, FALL
};

public class Q2sol {
	public static void main(String[] args) {

		Season s = Season.SUMMER;

		System.out.println(s);

		if (s != Season.FALL) {
			System.out.println("Season is not FALL");
		} else {
			System.out.println("Season is FALL");
		}

		System.out.println("Season is " + mySeason(s));
	}

	public static Season mySeason(Season season) {
		return season;
	}

}