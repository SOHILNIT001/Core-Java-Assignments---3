package Assignment3;

//#5. Try to override methods in Object class, prepare list of final methods defined in Object class?

public class Q5sol {

	public static void main(String[] args) {
		
		String str1 = "World";
		String str2 = "world";
		
		if (str1.equalsIgnoreCase(str2)) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
		
		System.out.println(str1.getClass());
		
		Q5sol fb = new Q5sol();
		System.out.println(fb.toString());
		
	}

	@Override
	public String toString() {
		return "Hello world!";
	}

//	The final methods in Object Class are :

//protected Object clone() throws CloneNotSupportedException
//public boolean equals(Object obj)
//protected void finalize() throws Throwable
//public final Class getClass()
//public int hashCode()
//public String toString()
//
//public final void notify()
//public final void notifyAll()
//public final void wait()
//public final void wait(long timeout)
//public final void wait(long timeout, int nanos)
}
